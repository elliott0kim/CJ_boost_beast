# Traits Examples

These example require upstream CMake installation to work. There are exceptions:

- For Boost.JSON headers must be located by custom CMake.
- For PicoJSON headers must be located by custom CMake.
